# Semantic checker and code generator

## Project Members
- Trent Wells

## How to Compile and Run
1. Open a terminal and navigate to the directory holding the project
2. Run “make” in the terminal
3. Use the command “./main all” to run all files (a1-a8)
4. Use the command “./main inputFilesP2/a1” to run a specific file (a directory must be specified)
5. RPN output will be stored in .rpn files